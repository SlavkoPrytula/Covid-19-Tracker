from setuptools import setup, find_packages

setup(
    name="COVID-19-Tracker",
    version="1.0",
    author="Yaroslav Prytula, Bogdan Sydor",
    author_email="slavko.prytula@gmail.com",
    packages=find_packages()
)
